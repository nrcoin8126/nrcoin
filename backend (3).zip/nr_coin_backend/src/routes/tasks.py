from flask import Blueprint, jsonify, request
from src.models.user import DailyTask, User, Wallet, CoinTransaction, Game, GameSession, db
from datetime import datetime, date
import random
import json

tasks_bp = Blueprint('tasks', __name__)

@tasks_bp.route('/daily-tasks', methods=['GET'])
def get_daily_tasks():
    """Get all active daily tasks"""
    tasks = DailyTask.query.filter_by(is_active=True).all()
    return jsonify({
        'tasks': [task.to_dict() for task in tasks]
    })

@tasks_bp.route('/daily-tasks/<int:user_id>/available', methods=['GET'])
def get_available_tasks(user_id):
    """Get available tasks for user (not completed today)"""
    from sqlalchemy import text
    
    # Get tasks not completed today by user
    query = text("""
        SELECT dt.* FROM daily_tasks dt
        LEFT JOIN user_task_completions utc ON dt.id = utc.task_id 
            AND utc.user_id = :user_id 
            AND utc.completion_date = :today
        WHERE dt.is_active = 1 
            AND (utc.id IS NULL OR 
                 (SELECT COUNT(*) FROM user_task_completions 
                  WHERE task_id = dt.id AND user_id = :user_id AND completion_date = :today) 
                 < dt.max_completions_per_day)
    """)
    
    result = db.session.execute(query, {
        'user_id': user_id,
        'today': date.today()
    })
    
    tasks = []
    for row in result:
        task = DailyTask.query.get(row.id)
        if task:
            tasks.append(task.to_dict())
    
    return jsonify({
        'available_tasks': tasks
    })

@tasks_bp.route('/daily-tasks/<int:task_id>/complete', methods=['POST'])
def complete_task(task_id):
    """Complete a daily task"""
    data = request.json
    user_id = data.get('user_id')
    
    if not user_id:
        return jsonify({'error': 'User ID is required'}), 400
    
    task = DailyTask.query.get_or_404(task_id)
    user = User.query.get_or_404(user_id)
    
    # Check if task already completed today
    from src.models.user import db
    existing_completion = db.session.execute(
        db.text("SELECT COUNT(*) as count FROM user_task_completions WHERE user_id = :user_id AND task_id = :task_id AND completion_date = :today"),
        {'user_id': user_id, 'task_id': task_id, 'today': date.today()}
    ).first()
    
    if existing_completion.count >= task.max_completions_per_day:
        return jsonify({'error': 'Task already completed for today'}), 400
    
    # Add coins to wallet
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if not wallet:
        wallet = Wallet(user_id=user_id)
        db.session.add(wallet)
    
    wallet.bonus_coins += task.reward_coins
    wallet.total_coins += task.reward_coins
    
    # Create transaction record
    transaction = CoinTransaction(
        user_id=user_id,
        transaction_type='earn',
        amount=task.reward_coins,
        balance_after=wallet.total_coins,
        description=f'Completed task: {task.title}',
        reference_id=str(task_id),
        reference_type='daily_task'
    )
    db.session.add(transaction)
    
    # Record task completion
    db.session.execute(
        db.text("INSERT INTO user_task_completions (user_id, task_id, completion_date, coins_earned, created_at) VALUES (:user_id, :task_id, :completion_date, :coins_earned, :created_at)"),
        {
            'user_id': user_id,
            'task_id': task_id,
            'completion_date': date.today(),
            'coins_earned': float(task.reward_coins),
            'created_at': datetime.utcnow()
        }
    )
    
    db.session.commit()
    
    return jsonify({
        'message': 'Task completed successfully',
        'coins_earned': float(task.reward_coins),
        'new_balance': float(wallet.total_coins)
    })

@tasks_bp.route('/spin-wheel/<int:user_id>', methods=['POST'])
def spin_wheel(user_id):
    """Spin the daily wheel"""
    user = User.query.get_or_404(user_id)
    
    # Check if user already spun today
    from src.models.user import db
    today_spin = db.session.execute(
        db.text("SELECT COUNT(*) as count FROM user_spins WHERE user_id = :user_id AND spin_date = :today"),
        {'user_id': user_id, 'today': date.today()}
    ).first()
    
    if today_spin.count > 0:
        return jsonify({'error': 'Already spun today'}), 400
    
    # Generate random reward (5-100 coins)
    reward_amount = random.randint(5, 100)
    
    # Add coins to wallet
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if not wallet:
        wallet = Wallet(user_id=user_id)
        db.session.add(wallet)
    
    wallet.bonus_coins += reward_amount
    wallet.total_coins += reward_amount
    
    # Create transaction record
    transaction = CoinTransaction(
        user_id=user_id,
        transaction_type='earn',
        amount=reward_amount,
        balance_after=wallet.total_coins,
        description='Daily spin reward',
        reference_type='daily_spin'
    )
    db.session.add(transaction)
    
    # Record spin
    db.session.execute(
        db.text("INSERT INTO user_spins (user_id, reward_amount, spin_date, created_at) VALUES (:user_id, :reward_amount, :spin_date, :created_at)"),
        {
            'user_id': user_id,
            'reward_amount': reward_amount,
            'spin_date': date.today(),
            'created_at': datetime.utcnow()
        }
    )
    
    db.session.commit()
    
    return jsonify({
        'message': 'Spin successful',
        'reward_amount': reward_amount,
        'new_balance': float(wallet.total_coins)
    })

@tasks_bp.route('/games', methods=['GET'])
def get_games():
    """Get all active games"""
    games = Game.query.filter_by(is_active=True).all()
    return jsonify({
        'games': [game.to_dict() for game in games]
    })

@tasks_bp.route('/games/<int:game_id>/play', methods=['POST'])
def play_game(game_id):
    """Play a game"""
    data = request.json
    user_id = data.get('user_id')
    bet_amount = float(data.get('bet_amount', 0))
    game_input = data.get('game_input', {})
    
    if not user_id:
        return jsonify({'error': 'User ID is required'}), 400
    
    game = Game.query.get_or_404(game_id)
    user = User.query.get_or_404(user_id)
    
    # Check bet limits
    if bet_amount < game.min_bet or bet_amount > game.max_bet:
        return jsonify({'error': f'Bet amount must be between {game.min_bet} and {game.max_bet}'}), 400
    
    # Check wallet balance
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if not wallet or wallet.total_coins < bet_amount:
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # Play game based on type
    result, payout, game_data = play_game_logic(game.game_type, bet_amount, game_input, game.house_edge)
    
    # Update wallet
    profit_loss = payout - bet_amount
    wallet.total_coins += profit_loss
    
    # Create game session record
    session = GameSession(
        user_id=user_id,
        game_id=game_id,
        bet_amount=bet_amount,
        result=result,
        payout=payout,
        profit_loss=profit_loss,
        game_data=game_data
    )
    db.session.add(session)
    
    # Create transaction record
    transaction = CoinTransaction(
        user_id=user_id,
        transaction_type='spend' if profit_loss < 0 else 'earn',
        amount=profit_loss,
        balance_after=wallet.total_coins,
        description=f'Game: {game.name} - {result}',
        reference_id=str(session.id),
        reference_type='game'
    )
    db.session.add(transaction)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Game played successfully',
        'result': result,
        'payout': payout,
        'profit_loss': profit_loss,
        'new_balance': float(wallet.total_coins),
        'game_data': game_data
    })

def play_game_logic(game_type, bet_amount, game_input, house_edge):
    """Game logic for different game types"""
    
    if game_type == 'coin_flip':
        user_choice = game_input.get('choice', 'heads')  # heads or tails
        result = random.choice(['heads', 'tails'])
        
        if user_choice == result:
            payout = bet_amount * 1.9  # 90% payout (10% house edge)
            game_result = 'win'
        else:
            payout = 0
            game_result = 'lose'
        
        game_data = {
            'user_choice': user_choice,
            'actual_result': result,
            'game_result': game_result
        }
        
        return game_result, payout, game_data
    
    elif game_type == 'dice':
        user_guess = game_input.get('guess', 7)  # sum of two dice
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        actual_sum = dice1 + dice2
        
        if user_guess == actual_sum:
            # Higher payout for exact match
            payout = bet_amount * 10
            game_result = 'win'
        else:
            payout = 0
            game_result = 'lose'
        
        game_data = {
            'user_guess': user_guess,
            'dice1': dice1,
            'dice2': dice2,
            'actual_sum': actual_sum,
            'game_result': game_result
        }
        
        return game_result, payout, game_data
    
    elif game_type == 'number_guess':
        user_number = game_input.get('number', 50)  # 1-100
        winning_number = random.randint(1, 100)
        
        if user_number == winning_number:
            payout = bet_amount * 50  # High payout for exact match
            game_result = 'exact_match'
        elif abs(user_number - winning_number) <= 5:
            payout = bet_amount * 5  # Medium payout for close
            game_result = 'close'
        elif abs(user_number - winning_number) <= 10:
            payout = bet_amount * 2  # Small payout for near
            game_result = 'near'
        else:
            payout = 0
            game_result = 'lose'
        
        game_data = {
            'user_number': user_number,
            'winning_number': winning_number,
            'difference': abs(user_number - winning_number),
            'game_result': game_result
        }
        
        return game_result, payout, game_data
    
    elif game_type == 'slots':
        symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎']
        reel1 = random.choice(symbols)
        reel2 = random.choice(symbols)
        reel3 = random.choice(symbols)
        
        if reel1 == reel2 == reel3:
            if reel1 == '💎':
                payout = bet_amount * 100  # Jackpot
                game_result = 'jackpot'
            elif reel1 == '⭐':
                payout = bet_amount * 50
                game_result = 'three_stars'
            else:
                payout = bet_amount * 10
                game_result = 'three_match'
        elif reel1 == reel2 or reel2 == reel3 or reel1 == reel3:
            payout = bet_amount * 2
            game_result = 'two_match'
        else:
            payout = 0
            game_result = 'no_match'
        
        game_data = {
            'reel1': reel1,
            'reel2': reel2,
            'reel3': reel3,
            'game_result': game_result
        }
        
        return game_result, payout, game_data
    
    else:
        # Default case
        return 'unknown', 0, {}

@tasks_bp.route('/games/<int:user_id>/history', methods=['GET'])
def get_game_history(user_id):
    """Get user's game history"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    sessions = GameSession.query.filter_by(user_id=user_id)\
        .order_by(GameSession.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'sessions': [s.to_dict() for s in sessions.items],
        'total': sessions.total,
        'pages': sessions.pages,
        'current_page': page
    })

