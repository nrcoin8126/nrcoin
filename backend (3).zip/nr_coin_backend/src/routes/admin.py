from flask import Blueprint, jsonify, request
from src.models.user import (User, Wallet, KYCDocument, WithdrawalRequest, DailyTask, 
                            Game, AppSetting, AdminUser, CoinTransaction, db)
from datetime import datetime
import json

admin_bp = Blueprint('admin', __name__)

# Dashboard Routes
@admin_bp.route('/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    """Get dashboard statistics"""
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    blocked_users = User.query.filter_by(is_blocked=True).count()
    
    pending_kyc = KYCDocument.query.filter_by(status='pending').count()
    verified_kyc = KYCDocument.query.filter_by(status='verified').count()
    
    pending_withdrawals = WithdrawalRequest.query.filter_by(status='pending').count()
    total_withdrawals = WithdrawalRequest.query.count()
    
    # Calculate total coins in circulation
    total_coins_query = db.session.execute(
        db.text("SELECT SUM(total_coins) as total FROM wallets")
    ).first()
    total_coins = float(total_coins_query.total) if total_coins_query.total else 0
    
    return jsonify({
        'users': {
            'total': total_users,
            'active': active_users,
            'blocked': blocked_users
        },
        'kyc': {
            'pending': pending_kyc,
            'verified': verified_kyc
        },
        'withdrawals': {
            'pending': pending_withdrawals,
            'total': total_withdrawals
        },
        'coins': {
            'total_in_circulation': total_coins
        }
    })

# User Management Routes
@admin_bp.route('/users', methods=['GET'])
def get_all_users():
    """Get all users with pagination"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    
    query = User.query
    
    if search:
        query = query.filter(
            db.or_(
                User.mobile.contains(search),
                User.name.contains(search),
                User.email.contains(search)
            )
        )
    
    users = query.paginate(page=page, per_page=per_page, error_out=False)
    
    user_data = []
    for user in users.items:
        wallet = Wallet.query.filter_by(user_id=user.id).first()
        kyc = KYCDocument.query.filter_by(user_id=user.id).first()
        
        user_dict = user.to_dict()
        user_dict['wallet'] = wallet.to_dict() if wallet else None
        user_dict['kyc_status'] = kyc.status if kyc else 'not_submitted'
        user_data.append(user_dict)
    
    return jsonify({
        'users': user_data,
        'total': users.total,
        'pages': users.pages,
        'current_page': page
    })

@admin_bp.route('/users/<int:user_id>/block', methods=['POST'])
def block_user(user_id):
    """Block/Unblock a user"""
    user = User.query.get_or_404(user_id)
    data = request.json
    
    user.is_blocked = data.get('block', True)
    user.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    action = 'blocked' if user.is_blocked else 'unblocked'
    return jsonify({
        'message': f'User {action} successfully',
        'user': user.to_dict()
    })

@admin_bp.route('/users/<int:user_id>/coins', methods=['POST'])
def distribute_coins(user_id):
    """Distribute coins to a user"""
    user = User.query.get_or_404(user_id)
    data = request.json
    
    amount = float(data.get('amount', 0))
    reason = data.get('reason', 'Admin distribution')
    
    if amount <= 0:
        return jsonify({'error': 'Amount must be positive'}), 400
    
    # Get or create wallet
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if not wallet:
        wallet = Wallet(user_id=user_id)
        db.session.add(wallet)
    
    # Add coins
    wallet.bonus_coins += amount
    wallet.total_coins += amount
    
    # Create transaction record
    transaction = CoinTransaction(
        user_id=user_id,
        transaction_type='earn',
        amount=amount,
        balance_after=wallet.total_coins,
        description=reason,
        reference_type='admin_distribution'
    )
    db.session.add(transaction)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Coins distributed successfully',
        'amount': amount,
        'new_balance': float(wallet.total_coins)
    })

# KYC Management Routes
@admin_bp.route('/kyc/pending', methods=['GET'])
def get_pending_kyc():
    """Get all pending KYC requests"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    kyc_requests = KYCDocument.query.filter_by(status='pending')\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    kyc_data = []
    for kyc in kyc_requests.items:
        user = User.query.get(kyc.user_id)
        kyc_dict = kyc.to_dict()
        kyc_dict['user'] = user.to_dict() if user else None
        kyc_data.append(kyc_dict)
    
    return jsonify({
        'kyc_requests': kyc_data,
        'total': kyc_requests.total,
        'pages': kyc_requests.pages,
        'current_page': page
    })

@admin_bp.route('/kyc/<int:kyc_id>/approve', methods=['POST'])
def approve_kyc(kyc_id):
    """Approve or reject KYC"""
    kyc = KYCDocument.query.get_or_404(kyc_id)
    data = request.json
    
    action = data.get('action')  # 'approve' or 'reject'
    admin_id = data.get('admin_id')
    reason = data.get('reason', '')
    
    if action == 'approve':
        kyc.status = 'verified'
        kyc.verified_by = admin_id
        kyc.verified_at = datetime.utcnow()
    elif action == 'reject':
        kyc.status = 'rejected'
        kyc.rejection_reason = reason
    else:
        return jsonify({'error': 'Invalid action'}), 400
    
    kyc.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'message': f'KYC {action}d successfully',
        'kyc': kyc.to_dict()
    })

# Withdrawal Management Routes
@admin_bp.route('/withdrawals/pending', methods=['GET'])
def get_pending_withdrawals():
    """Get all pending withdrawal requests"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    withdrawals = WithdrawalRequest.query.filter_by(status='pending')\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    withdrawal_data = []
    for withdrawal in withdrawals.items:
        user = User.query.get(withdrawal.user_id)
        withdrawal_dict = withdrawal.to_dict()
        withdrawal_dict['user'] = user.to_dict() if user else None
        withdrawal_data.append(withdrawal_dict)
    
    return jsonify({
        'withdrawals': withdrawal_data,
        'total': withdrawals.total,
        'pages': withdrawals.pages,
        'current_page': page
    })

@admin_bp.route('/withdrawals/<int:withdrawal_id>/process', methods=['POST'])
def process_withdrawal(withdrawal_id):
    """Process withdrawal request"""
    withdrawal = WithdrawalRequest.query.get_or_404(withdrawal_id)
    data = request.json
    
    action = data.get('action')  # 'approve' or 'reject'
    admin_id = data.get('admin_id')
    notes = data.get('notes', '')
    
    if action == 'approve':
        withdrawal.status = 'approved'
        # In production, integrate with payment gateway here
        
    elif action == 'reject':
        withdrawal.status = 'rejected'
        
        # Return coins to user wallet
        wallet = Wallet.query.filter_by(user_id=withdrawal.user_id).first()
        if wallet:
            wallet.locked_coins -= withdrawal.amount
            wallet.total_coins += withdrawal.amount
            
            # Create transaction record
            transaction = CoinTransaction(
                user_id=withdrawal.user_id,
                transaction_type='earn',
                amount=withdrawal.amount,
                balance_after=wallet.total_coins,
                description='Withdrawal rejected - coins returned',
                reference_type='withdrawal_rejected'
            )
            db.session.add(transaction)
    else:
        return jsonify({'error': 'Invalid action'}), 400
    
    withdrawal.admin_notes = notes
    withdrawal.processed_by = admin_id
    withdrawal.processed_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': f'Withdrawal {action}d successfully',
        'withdrawal': withdrawal.to_dict()
    })

# Task Management Routes
@admin_bp.route('/tasks', methods=['GET'])
def get_all_tasks():
    """Get all daily tasks"""
    tasks = DailyTask.query.all()
    return jsonify({
        'tasks': [task.to_dict() for task in tasks]
    })

@admin_bp.route('/tasks', methods=['POST'])
def create_task():
    """Create a new daily task"""
    data = request.json
    
    task = DailyTask(
        title=data.get('title'),
        description=data.get('description'),
        task_type=data.get('task_type'),
        reward_coins=data.get('reward_coins'),
        max_completions_per_day=data.get('max_completions_per_day', 1),
        external_url=data.get('external_url')
    )
    
    db.session.add(task)
    db.session.commit()
    
    return jsonify({
        'message': 'Task created successfully',
        'task': task.to_dict()
    })

@admin_bp.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """Update a daily task"""
    task = DailyTask.query.get_or_404(task_id)
    data = request.json
    
    task.title = data.get('title', task.title)
    task.description = data.get('description', task.description)
    task.task_type = data.get('task_type', task.task_type)
    task.reward_coins = data.get('reward_coins', task.reward_coins)
    task.max_completions_per_day = data.get('max_completions_per_day', task.max_completions_per_day)
    task.is_active = data.get('is_active', task.is_active)
    task.external_url = data.get('external_url', task.external_url)
    task.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Task updated successfully',
        'task': task.to_dict()
    })

@admin_bp.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """Delete a daily task"""
    task = DailyTask.query.get_or_404(task_id)
    
    db.session.delete(task)
    db.session.commit()
    
    return jsonify({
        'message': 'Task deleted successfully'
    })

# Game Management Routes
@admin_bp.route('/games', methods=['GET'])
def get_all_games():
    """Get all games"""
    games = Game.query.all()
    return jsonify({
        'games': [game.to_dict() for game in games]
    })

@admin_bp.route('/games', methods=['POST'])
def create_game():
    """Create a new game"""
    data = request.json
    
    game = Game(
        name=data.get('name'),
        game_type=data.get('game_type'),
        min_bet=data.get('min_bet', 1.0),
        max_bet=data.get('max_bet', 100.0),
        house_edge=data.get('house_edge', 0.05)
    )
    
    db.session.add(game)
    db.session.commit()
    
    return jsonify({
        'message': 'Game created successfully',
        'game': game.to_dict()
    })

@admin_bp.route('/games/<int:game_id>', methods=['PUT'])
def update_game(game_id):
    """Update a game"""
    game = Game.query.get_or_404(game_id)
    data = request.json
    
    game.name = data.get('name', game.name)
    game.game_type = data.get('game_type', game.game_type)
    game.min_bet = data.get('min_bet', game.min_bet)
    game.max_bet = data.get('max_bet', game.max_bet)
    game.house_edge = data.get('house_edge', game.house_edge)
    game.is_active = data.get('is_active', game.is_active)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Game updated successfully',
        'game': game.to_dict()
    })

# App Settings Routes
@admin_bp.route('/settings', methods=['GET'])
def get_app_settings():
    """Get all app settings"""
    settings = AppSetting.query.all()
    
    settings_dict = {}
    for setting in settings:
        value = setting.setting_value
        
        # Convert based on data type
        if setting.data_type == 'number':
            value = float(value) if value else 0
        elif setting.data_type == 'boolean':
            value = value.lower() == 'true' if value else False
        elif setting.data_type == 'json':
            value = json.loads(value) if value else {}
        
        settings_dict[setting.setting_key] = {
            'value': value,
            'data_type': setting.data_type,
            'description': setting.description
        }
    
    return jsonify({
        'settings': settings_dict
    })

@admin_bp.route('/settings', methods=['POST'])
def update_app_settings():
    """Update app settings"""
    data = request.json
    admin_id = data.get('admin_id')
    
    for key, value_data in data.get('settings', {}).items():
        setting = AppSetting.query.filter_by(setting_key=key).first()
        
        if not setting:
            setting = AppSetting(setting_key=key)
            db.session.add(setting)
        
        # Convert value to string for storage
        value = value_data.get('value')
        data_type = value_data.get('data_type', 'string')
        
        if data_type == 'json':
            setting.setting_value = json.dumps(value)
        else:
            setting.setting_value = str(value)
        
        setting.data_type = data_type
        setting.description = value_data.get('description', '')
        setting.updated_by = admin_id
        setting.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Settings updated successfully'
    })

# Analytics Routes
@admin_bp.route('/analytics/users', methods=['GET'])
def get_user_analytics():
    """Get user analytics"""
    # Daily registrations for last 30 days
    daily_registrations = db.session.execute(
        db.text("""
            SELECT DATE(created_at) as date, COUNT(*) as count 
            FROM users 
            WHERE created_at >= datetime('now', '-30 days')
            GROUP BY DATE(created_at)
            ORDER BY date
        """)
    ).fetchall()
    
    return jsonify({
        'daily_registrations': [
            {'date': row.date, 'count': row.count} 
            for row in daily_registrations
        ]
    })

@admin_bp.route('/analytics/coins', methods=['GET'])
def get_coin_analytics():
    """Get coin analytics"""
    # Coin distribution by type
    coin_distribution = db.session.execute(
        db.text("""
            SELECT 
                SUM(total_coins) as total,
                SUM(bonus_coins) as bonus,
                SUM(referral_coins) as referral,
                SUM(mining_coins) as mining
            FROM wallets
        """)
    ).first()
    
    return jsonify({
        'coin_distribution': {
            'total': float(coin_distribution.total) if coin_distribution.total else 0,
            'bonus': float(coin_distribution.bonus) if coin_distribution.bonus else 0,
            'referral': float(coin_distribution.referral) if coin_distribution.referral else 0,
            'mining': float(coin_distribution.mining) if coin_distribution.mining else 0
        }
    })

