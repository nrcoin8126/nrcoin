from flask import Blueprint, jsonify, request
from src.models.user import User, Wallet, KYCDocument, CoinTransaction, WithdrawalRequest, db
import random
import string
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/send-otp', methods=['POST'])
def send_otp():
    """Send OTP to mobile number"""
    data = request.json
    mobile = data.get('mobile')
    
    if not mobile:
        return jsonify({'error': 'Mobile number is required'}), 400
    
    # Generate 6-digit OTP
    otp = ''.join(random.choices(string.digits, k=6))
    
    # In production, send actual OTP via SMS service
    # For demo, we'll return the OTP
    return jsonify({
        'message': 'OTP sent successfully',
        'otp': otp,  # Remove this in production
        'mobile': mobile
    })

@auth_bp.route('/verify-otp', methods=['POST'])
def verify_otp():
    """Verify OTP and login/register user"""
    data = request.json
    mobile = data.get('mobile')
    otp = data.get('otp')
    referral_code = data.get('referral_code')
    device_id = data.get('device_id')
    
    if not mobile or not otp:
        return jsonify({'error': 'Mobile and OTP are required'}), 400
    
    # In production, verify OTP from cache/database
    # For demo, accept any 6-digit OTP
    if len(otp) != 6 or not otp.isdigit():
        return jsonify({'error': 'Invalid OTP'}), 400
    
    # Check if user exists
    user = User.query.filter_by(mobile=mobile).first()
    
    if not user:
        # Create new user
        user = User(mobile=mobile, device_id=device_id)
        
        # Handle referral
        if referral_code:
            referrer = User.query.filter_by(referral_code=referral_code).first()
            if referrer:
                user.referred_by = referrer.id
        
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Create wallet
        wallet = Wallet(user_id=user.id)
        db.session.add(wallet)
        
        # Give signup bonus
        signup_bonus = 100.0
        wallet.bonus_coins = signup_bonus
        wallet.total_coins = signup_bonus
        
        # Create transaction record
        transaction = CoinTransaction(
            user_id=user.id,
            transaction_type='earn',
            amount=signup_bonus,
            balance_after=signup_bonus,
            description='Signup bonus',
            reference_type='signup_bonus'
        )
        db.session.add(transaction)
        
        # Give referral bonus to referrer
        if referral_code and referrer:
            referral_bonus = 50.0
            referrer_wallet = Wallet.query.filter_by(user_id=referrer.id).first()
            if referrer_wallet:
                referrer_wallet.referral_coins += referral_bonus
                referrer_wallet.total_coins += referral_bonus
                
                # Create transaction for referrer
                referrer_transaction = CoinTransaction(
                    user_id=referrer.id,
                    transaction_type='earn',
                    amount=referral_bonus,
                    balance_after=referrer_wallet.total_coins,
                    description=f'Referral bonus for {mobile}',
                    reference_type='referral_bonus'
                )
                db.session.add(referrer_transaction)
        
        db.session.commit()
        is_new_user = True
    else:
        # Update device ID if provided
        if device_id:
            user.device_id = device_id
            db.session.commit()
        is_new_user = False
    
    # Get user wallet
    wallet = Wallet.query.filter_by(user_id=user.id).first()
    
    return jsonify({
        'message': 'Login successful',
        'user': user.to_dict(),
        'wallet': wallet.to_dict() if wallet else None,
        'is_new_user': is_new_user
    })

@auth_bp.route('/profile/<int:user_id>', methods=['GET'])
def get_profile(user_id):
    """Get user profile"""
    user = User.query.get_or_404(user_id)
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    kyc = KYCDocument.query.filter_by(user_id=user_id).first()
    
    return jsonify({
        'user': user.to_dict(),
        'wallet': wallet.to_dict() if wallet else None,
        'kyc': kyc.to_dict() if kyc else None
    })

@auth_bp.route('/profile/<int:user_id>', methods=['PUT'])
def update_profile(user_id):
    """Update user profile"""
    user = User.query.get_or_404(user_id)
    data = request.json
    
    user.name = data.get('name', user.name)
    user.email = data.get('email', user.email)
    user.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Profile updated successfully',
        'user': user.to_dict()
    })

@auth_bp.route('/kyc/<int:user_id>', methods=['POST'])
def submit_kyc(user_id):
    """Submit KYC documents"""
    user = User.query.get_or_404(user_id)
    data = request.json
    
    # Check if KYC already exists
    kyc = KYCDocument.query.filter_by(user_id=user_id).first()
    
    if not kyc:
        kyc = KYCDocument(user_id=user_id)
    
    kyc.aadhaar_number = data.get('aadhaar_number')
    kyc.pan_number = data.get('pan_number')
    kyc.aadhaar_document_url = data.get('aadhaar_document_url')
    kyc.pan_document_url = data.get('pan_document_url')
    kyc.status = 'pending'
    kyc.updated_at = datetime.utcnow()
    
    if not KYCDocument.query.filter_by(user_id=user_id).first():
        db.session.add(kyc)
    
    db.session.commit()
    
    return jsonify({
        'message': 'KYC documents submitted successfully',
        'kyc': kyc.to_dict()
    })

@auth_bp.route('/wallet/<int:user_id>/transactions', methods=['GET'])
def get_transactions(user_id):
    """Get user transaction history"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    transactions = CoinTransaction.query.filter_by(user_id=user_id)\
        .order_by(CoinTransaction.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'transactions': [t.to_dict() for t in transactions.items],
        'total': transactions.total,
        'pages': transactions.pages,
        'current_page': page
    })

@auth_bp.route('/withdrawal/<int:user_id>', methods=['POST'])
def request_withdrawal(user_id):
    """Request withdrawal"""
    user = User.query.get_or_404(user_id)
    data = request.json
    
    # Check KYC status
    kyc = KYCDocument.query.filter_by(user_id=user_id).first()
    if not kyc or kyc.status != 'verified':
        return jsonify({'error': 'KYC verification required for withdrawal'}), 400
    
    # Check wallet balance
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    amount = float(data.get('amount', 0))
    
    if not wallet or wallet.total_coins < amount:
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # Create withdrawal request
    withdrawal = WithdrawalRequest(
        user_id=user_id,
        amount=amount,
        withdrawal_method=data.get('withdrawal_method'),
        upi_id=data.get('upi_id'),
        bank_account_number=data.get('bank_account_number'),
        ifsc_code=data.get('ifsc_code'),
        bank_name=data.get('bank_name'),
        account_holder_name=data.get('account_holder_name')
    )
    
    db.session.add(withdrawal)
    
    # Lock coins
    wallet.locked_coins += amount
    wallet.total_coins -= amount
    
    # Create transaction record
    transaction = CoinTransaction(
        user_id=user_id,
        transaction_type='withdraw',
        amount=-amount,
        balance_after=wallet.total_coins,
        description='Withdrawal request',
        reference_type='withdrawal',
        status='pending'
    )
    db.session.add(transaction)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Withdrawal request submitted successfully',
        'withdrawal': withdrawal.to_dict()
    })

@auth_bp.route('/withdrawal/<int:user_id>/history', methods=['GET'])
def get_withdrawal_history(user_id):
    """Get withdrawal history"""
    withdrawals = WithdrawalRequest.query.filter_by(user_id=user_id)\
        .order_by(WithdrawalRequest.created_at.desc()).all()
    
    return jsonify({
        'withdrawals': [w.to_dict() for w in withdrawals]
    })

