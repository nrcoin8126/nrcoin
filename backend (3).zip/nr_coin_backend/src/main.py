import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.tasks import tasks_bp
from src.routes.admin import admin_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app)

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(tasks_bp, url_prefix='/api/tasks')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Initialize database and create default data
with app.app_context():
    db.create_all()
    
    # Create default games if they don't exist
    from src.models.user import Game, DailyTask, AppSetting
    
    if Game.query.count() == 0:
        default_games = [
            Game(name='Coin Flip', game_type='coin_flip', min_bet=1, max_bet=100, house_edge=0.05),
            Game(name='Lucky Dice', game_type='dice', min_bet=1, max_bet=50, house_edge=0.08),
            Game(name='Number Guess', game_type='number_guess', min_bet=1, max_bet=20, house_edge=0.15),
            Game(name='Fruit Slots', game_type='slots', min_bet=1, max_bet=200, house_edge=0.10)
        ]
        
        for game in default_games:
            db.session.add(game)
    
    # Create default tasks if they don't exist
    if DailyTask.query.count() == 0:
        default_tasks = [
            DailyTask(title='Watch Video Ad', description='Watch a 30-second video ad', task_type='video_ad', reward_coins=5, max_completions_per_day=10),
            DailyTask(title='View Banner Ad', description='View banner advertisement', task_type='banner_ad', reward_coins=2, max_completions_per_day=20),
            DailyTask(title='Complete Survey', description='Complete a short survey', task_type='survey', reward_coins=15, max_completions_per_day=3),
            DailyTask(title='Daily Login', description='Login to the app', task_type='daily_login', reward_coins=10, max_completions_per_day=1),
            DailyTask(title='Install App', description='Install recommended app', task_type='app_install', reward_coins=25, max_completions_per_day=5)
        ]
        
        for task in default_tasks:
            db.session.add(task)
    
    # Create default app settings if they don't exist
    if AppSetting.query.count() == 0:
        default_settings = [
            AppSetting(setting_key='coin_to_inr_rate', setting_value='0.10', data_type='number', description='Conversion rate from coins to INR'),
            AppSetting(setting_key='minimum_withdrawal', setting_value='100', data_type='number', description='Minimum withdrawal amount in coins'),
            AppSetting(setting_key='referral_bonus', setting_value='50', data_type='number', description='Referral bonus in coins'),
            AppSetting(setting_key='signup_bonus', setting_value='100', data_type='number', description='Signup bonus in coins'),
            AppSetting(setting_key='daily_spin_enabled', setting_value='true', data_type='boolean', description='Enable daily spin feature'),
            AppSetting(setting_key='maintenance_mode', setting_value='false', data_type='boolean', description='Enable maintenance mode')
        ]
        
        for setting in default_settings:
            db.session.add(setting)
    
    db.session.commit()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
