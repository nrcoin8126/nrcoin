from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets
import string

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    mobile = db.Column(db.String(15), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=True)
    name = db.Column(db.String(255), nullable=True)
    referral_code = db.Column(db.String(20), unique=True, nullable=False)
    referred_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    device_id = db.Column(db.String(255), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    is_blocked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    wallet = db.relationship('Wallet', backref='user', uselist=False, cascade='all, delete-orphan')
    kyc_document = db.relationship('KYCDocument', backref='user', uselist=False, cascade='all, delete-orphan', foreign_keys='KYCDocument.user_id')
    transactions = db.relationship('CoinTransaction', backref='user', cascade='all, delete-orphan')
    withdrawal_requests = db.relationship('WithdrawalRequest', backref='user', cascade='all, delete-orphan', foreign_keys='WithdrawalRequest.user_id')
    game_sessions = db.relationship('GameSession', backref='user', cascade='all, delete-orphan')
    orders = db.relationship('Order', backref='user', cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', cascade='all, delete-orphan')
    
    def __init__(self, **kwargs):
        super(User, self).__init__(**kwargs)
        if not self.referral_code:
            self.referral_code = self.generate_referral_code()
    
    def generate_referral_code(self):
        """Generate a unique referral code"""
        while True:
            code = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
            if not User.query.filter_by(referral_code=code).first():
                return code

    def to_dict(self):
        return {
            'id': self.id,
            'mobile': self.mobile,
            'email': self.email,
            'name': self.name,
            'referral_code': self.referral_code,
            'referred_by': self.referred_by,
            'device_id': self.device_id,
            'is_active': self.is_active,
            'is_blocked': self.is_blocked,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Wallet(db.Model):
    __tablename__ = 'wallets'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_coins = db.Column(db.Numeric(15, 2), default=0.00)
    bonus_coins = db.Column(db.Numeric(15, 2), default=0.00)
    referral_coins = db.Column(db.Numeric(15, 2), default=0.00)
    mining_coins = db.Column(db.Numeric(15, 2), default=0.00)
    locked_coins = db.Column(db.Numeric(15, 2), default=0.00)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'total_coins': float(self.total_coins),
            'bonus_coins': float(self.bonus_coins),
            'referral_coins': float(self.referral_coins),
            'mining_coins': float(self.mining_coins),
            'locked_coins': float(self.locked_coins),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class KYCDocument(db.Model):
    __tablename__ = 'kyc_documents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    aadhaar_number = db.Column(db.String(12), nullable=True)
    pan_number = db.Column(db.String(10), nullable=True)
    aadhaar_document_url = db.Column(db.String(500), nullable=True)
    pan_document_url = db.Column(db.String(500), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, verified, rejected
    rejection_reason = db.Column(db.Text, nullable=True)
    verified_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    verified_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'aadhaar_number': self.aadhaar_number,
            'pan_number': self.pan_number,
            'aadhaar_document_url': self.aadhaar_document_url,
            'pan_document_url': self.pan_document_url,
            'status': self.status,
            'rejection_reason': self.rejection_reason,
            'verified_by': self.verified_by,
            'verified_at': self.verified_at.isoformat() if self.verified_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CoinTransaction(db.Model):
    __tablename__ = 'coin_transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)  # earn, spend, send, receive, withdraw, deposit
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    balance_after = db.Column(db.Numeric(15, 2), nullable=False)
    description = db.Column(db.Text, nullable=True)
    reference_id = db.Column(db.String(100), nullable=True)
    reference_type = db.Column(db.String(50), nullable=True)  # game, task, referral, purchase, etc.
    status = db.Column(db.String(20), default='completed')  # pending, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'transaction_type': self.transaction_type,
            'amount': float(self.amount),
            'balance_after': float(self.balance_after),
            'description': self.description,
            'reference_id': self.reference_id,
            'reference_type': self.reference_type,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class WithdrawalRequest(db.Model):
    __tablename__ = 'withdrawal_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    withdrawal_method = db.Column(db.String(20), nullable=False)  # upi, bank
    upi_id = db.Column(db.String(100), nullable=True)
    bank_account_number = db.Column(db.String(20), nullable=True)
    ifsc_code = db.Column(db.String(15), nullable=True)
    bank_name = db.Column(db.String(255), nullable=True)
    account_holder_name = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected, completed
    admin_notes = db.Column(db.Text, nullable=True)
    processed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    processed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'amount': float(self.amount),
            'withdrawal_method': self.withdrawal_method,
            'upi_id': self.upi_id,
            'bank_account_number': self.bank_account_number,
            'ifsc_code': self.ifsc_code,
            'bank_name': self.bank_name,
            'account_holder_name': self.account_holder_name,
            'status': self.status,
            'admin_notes': self.admin_notes,
            'processed_by': self.processed_by,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class DailyTask(db.Model):
    __tablename__ = 'daily_tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    task_type = db.Column(db.String(50), nullable=False)  # video_ad, banner_ad, app_install, survey, etc.
    reward_coins = db.Column(db.Numeric(10, 2), nullable=False)
    max_completions_per_day = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    external_url = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'task_type': self.task_type,
            'reward_coins': float(self.reward_coins),
            'max_completions_per_day': self.max_completions_per_day,
            'is_active': self.is_active,
            'external_url': self.external_url,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Game(db.Model):
    __tablename__ = 'games'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    game_type = db.Column(db.String(50), nullable=False)  # coin_flip, dice, number_guess, slots, memory
    min_bet = db.Column(db.Numeric(10, 2), default=1.00)
    max_bet = db.Column(db.Numeric(10, 2), default=100.00)
    house_edge = db.Column(db.Numeric(5, 4), default=0.05)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sessions = db.relationship('GameSession', backref='game', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'game_type': self.game_type,
            'min_bet': float(self.min_bet),
            'max_bet': float(self.max_bet),
            'house_edge': float(self.house_edge),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class GameSession(db.Model):
    __tablename__ = 'game_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    bet_amount = db.Column(db.Numeric(10, 2), nullable=False)
    result = db.Column(db.String(50), nullable=True)
    payout = db.Column(db.Numeric(10, 2), default=0.00)
    profit_loss = db.Column(db.Numeric(10, 2), nullable=True)
    game_data = db.Column(db.JSON, nullable=True)  # Store game-specific data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'game_id': self.game_id,
            'bet_amount': float(self.bet_amount),
            'result': self.result,
            'payout': float(self.payout),
            'profit_loss': float(self.profit_loss) if self.profit_loss else None,
            'game_data': self.game_data,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    order_number = db.Column(db.String(50), unique=True, nullable=False)
    total_coins = db.Column(db.Numeric(15, 2), nullable=False)
    total_inr = db.Column(db.Numeric(15, 2), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, shipped, delivered, cancelled
    shipping_address = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'order_number': self.order_number,
            'total_coins': float(self.total_coins),
            'total_inr': float(self.total_inr) if self.total_inr else None,
            'status': self.status,
            'shipping_address': self.shipping_address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    notification_type = db.Column(db.String(50), nullable=True)  # system, kyc, withdrawal, bonus, etc.
    is_read = db.Column(db.Boolean, default=False)
    data = db.Column(db.JSON, nullable=True)  # Additional notification data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'message': self.message,
            'notification_type': self.notification_type,
            'is_read': self.is_read,
            'data': self.data,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class AppSetting(db.Model):
    __tablename__ = 'app_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), unique=True, nullable=False)
    setting_value = db.Column(db.Text, nullable=True)
    data_type = db.Column(db.String(20), default='string')  # string, number, boolean, json
    description = db.Column(db.Text, nullable=True)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'setting_key': self.setting_key,
            'setting_value': self.setting_value,
            'data_type': self.data_type,
            'description': self.description,
            'updated_by': self.updated_by,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class AdminUser(db.Model):
    __tablename__ = 'admin_users'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    role = db.Column(db.String(50), default='admin')  # admin, super_admin, moderator
    permissions = db.Column(db.JSON, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    user = db.relationship('User', backref='admin_profile')
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'role': self.role,
            'permissions': self.permissions,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

